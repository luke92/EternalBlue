#Remake The EternalBlue Website

You broke the EternalBlue's website, it's now up to you to make a new one.

Your task is to make a new website for EternalBlue.
It's up to you to choose the best tools for the job.
**It's important that the website has an easily maintainable and readable codebase, so it won't break again.**

The site should have 3 screens:
1. The first screen should have a password field and a login button. It should have a hidden input field with the first password in a ASCII format. When the user types in the correct password navigating to page 2
2. The second screen should have a input field and a login button. It should contain the image from the EternalBlue website. When the user types in the correct password navigate to Page 3
3. The third screen should include a title congratulating the user on logging in. It should include a download button. The download button should download the Task.md file.

When the site is done, please submit your application here:
https://smrtr.io/4Szwm

And send a zip file of the codebase to: eternalblue@ifs.aero