Steps to run project.

Create a new ASP.NET MVC Project.

Copy LoginController from Controller folder.
Copy LoginViewModel from Models folder
Copy AfterLogin.cshmtl, index.html, Task.chstml from view folder.
Copy Task.md from File folder.


Copy site.css from content folder.

Build and execute project. 

Note - I did not packages folder in the code due to size issue. I didnt' use any additional nuget package for thsi project.